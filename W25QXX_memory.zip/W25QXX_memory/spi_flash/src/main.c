/*    Aman   */

#include <stdio.h>  // required header files
#include <string.h>
#include <zephyr/device.h>
#include <zephyr/devicetree.h>
#include <zephyr/drivers/flash.h>
#include <zephyr/zephyr.h>

// Conditional compilation based on board configurations
#if defined(CONFIG_BOARD_ADAFRUIT_FEATHER_STM32F405)
#define SPI_FLASH_TEST_REGION_OFFSET 0xf000
#elif defined(CONFIG_BOARD_ARTY_A7_ARM_DESIGNSTART_M1) ||                                          \
	defined(CONFIG_BOARD_ARTY_A7_ARM_DESIGNSTART_M3)
/* The FPGA bitstream is stored in the lower 536 sectors of the flash. */
#define SPI_FLASH_TEST_REGION_OFFSET DT_REG_SIZE(DT_NODE_BY_FIXED_PARTITION_LABEL(fpga_bitstream))
#elif defined(CONFIG_BOARD_NPCX9M6F_EVB) || defined(CONFIG_BOARD_NPCX7M6FB_EVB)
#define SPI_FLASH_TEST_REGION_OFFSET 0x7F000
#else
#define SPI_FLASH_TEST_REGION_OFFSET 0xff000
#endif
#define SPI_FLASH_SECTOR_SIZE 4096  // Defining sector size for flash operations
#define FLASH NAME "W25R64JV"       // Defining flash name for identification

void main(void)
{
	const uint8_t expected[] = {0x55, 0xaa, 0x66, 0x99}; // Expected data to be written to flash
	// const uint8_t expected[] = {0x};
	const size_t len = sizeof(expected); // Length of expected data
	uint8_t buf[sizeof(expected)]; // Buffer for storing read data

        /* Initializing on board flash device. */
	const struct device *flash_dev; // Flash device pointer
	int rc;

	flash_dev = DEVICE_DT_GET(DT_ALIAS(spi_flash0)); // Retrieving flash device from devicetree alias

	if (!device_is_ready(flash_dev)) {  // Checking if flash device is ready     
		printk("%s: device not ready.\n", flash_dev->name); // Printing error message if flash device is not ready
		return;
	} 

	printf("\n%s SPI flash testing\n", flash_dev->name);
	printf("==========================\n");

	/* Write protection needs to be disabled before each write or
	 * erase, since the flash component turns on write protection
	 * automatically after completion of write and erase
	 * operations.
	 */
	printf("\nTest 1: Flash erase\n"); // printing flash erase message

	/* Full flash erase if SPI_FLASH_TEST_REGION_OFFSET = 0 and
	 * SPI_FLASH_SECTOR_SIZE = flash size
	 */
	rc = flash_erase(flash_dev, SPI_FLASH_TEST_REGION_OFFSET, SPI_FLASH_SECTOR_SIZE); // Erasing flash sector
	if (rc != 0) {
		printf("Flash erase failed! %d\n", rc);
	} else {
		printf("Flash erase succeeded!\n");
	}

	printf("\nTest 2: Flash write\n");

	printf("Attempting to write %zu bytes\n", len);
	rc = flash_write(flash_dev, SPI_FLASH_TEST_REGION_OFFSET, expected, len);
	if (rc != 0) {
		printf("Flash write failed! %d\n", rc);
		return;
	}

	memset(buf, 0, len);
	rc = flash_read(flash_dev, SPI_FLASH_TEST_REGION_OFFSET, buf, len);
	if (rc != 0) {
		printf("Flash read failed! %d\n", rc);
		return;
	}

	if (memcmp(expected, buf, len) == 0) { // Checking if read data matches expected data
		printf("Data read matches data written. Very Good Aman!\n");
		for (int i = 0; i < sizeof(buf); i++) {
			printk("%x ", buf[i]);
		}
	} else {
		const uint8_t *wp = expected; // Pointer to expected data
		const uint8_t *rp = buf; // Pointer to read data
		const uint8_t *rpe = rp + len; // End pointer for read data

		printf("Data read does not match data written!!\n");
		// for (int i = 0; i < sizeof(buf); i++) {
		// 	printk("%x ", buf[i]);
		// }
		while (rp < rpe) {  // Looping through read and expected data
			printf("%08x wrote %02x read %02x %s\n",
			       (uint32_t)(SPI_FLASH_TEST_REGION_OFFSET + (rp - buf)), *wp, *rp,
			       (*rp == *wp) ? "match" : "MISMATCH");
			++rp;  // Moving to next byte in read data
			++wp;  // Moving to next byte in expected data
		}
	}
}