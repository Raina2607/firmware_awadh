#include <zephyr/kernel.h>   // headers for the project
#include <zephyr/sys/printk.h>
#include <zephyr/sys_clock.h>
#include <stdio.h>
#include <zephyr/device.h>
#include <zephyr/drivers/sensor.h>
#include <zephyr/drivers/i2c.h>
#include <zephyr/zephyr.h>                         // header files for the project       
#include <zephyr/drivers/sensor/sht4x.h>


#if defined(CONFIG_VCNL4040_ENABLE_ALS)  // Check if the macro CONFIG_VCNL4040_ENABLE_ALS is defined
static void print_als_data(const struct device *dev)  // Function declaration for printing ALS (Ambient Light Sensor) data
{
	struct sensor_value val;   // Declaration of a variable named `val` of type `struct sensor_value`

	if (sensor_channel_get(dev, SENSOR_CHAN_LIGHT, &val) < 0) {//fetching sensor lux data and storing in val
		printf("ALS read error.\n");   // Print an error message indicating that there was an ALS (Ambient Light Sensor) read error
		return;  // Exit the function, as there's nothing more to be done after encountering the error
	}

	printf("Light (lux): %d\n", (uint16_t) val.val1); //val1 stores the integer part of the val
}
#endif  // End of a conditional compilation block started with #if directive
static void test_polling_mode(const struct device *dev)   // Function definition for test_polling_mode, which likely tests polling mode of a device
{
		if (sensor_sample_fetch(dev) < 0) {
			// printf("sample update error.\n");//if the sensor data isn't fetched it prints this statement
		} else {
			// print_proxy_data(dev);//goes into the function to print proxy data
#if defined(CONFIG_VCNL4040_ENABLE_ALS) //if the config is enabled, enters the function print_als_data, prints lux data
			print_als_data(dev);
#endif  // End of a conditional compilation block started with #if directive
		}

}

int main(void)   // main function
{
	
	const struct device *const vcnl = DEVICE_DT_GET_ANY(vishay_vcnl4040);  // Declaration and initialization of a constant pointer to a constant device structure  & // The device is retrieved using DEVICE_DT_GET_ANY() macro with the compatible string "vishay_vcnl4040"
    const struct device *sht = DEVICE_DT_GET_ANY(sensirion_sht4x);   //define sensirion sht4x inside devicetree
    int err; ///creating variable 
    struct sensor_value temp,hum;     // Declare variables to store sensor values for temperature and humidity


    if(!device_is_ready(sht))                 // Check if the SHT device is not ready
    {
        printf("device %s is not ready\n",sht->name);         // Print an error message indicating that the device is not ready
        return;                                            // Exit the function
    }

	if (!device_is_ready(vcnl)) { // Check if the device pointed to by 'vcnl' is not ready
		printk("sensor: device not ready.\n"); //if the i2c address doesn't match or wrong assignments of pins, this is printed
		return 0;  // Return 0 to indicate successful completion of the function
	}
	printk("Starting vcnl4040 for Lux \n");
	while(1){//initialise loop to continuosly fetch data
      err= sensor_sample_fetch(sht);                    // Fetch sensor samples from the SHT device

    if (err==0)                                          // Check if the sampling operation was successful
    {
        sensor_channel_get(sht,SENSOR_CHAN_AMBIENT_TEMP,&temp);   // Declare variables to store temperature and humidity values
        sensor_channel_get(sht,SENSOR_CHAN_HUMIDITY,&hum);         
   
        printf("Temperature= %f C; Humidity= %f %%RH\n", sensor_value_to_double(&temp), sensor_value_to_double(&hum));   // Print temperature and humidity values
    }

    else{                                                                      // If there was an error fetching sensor samples
        printf("ERROR: Temperature data update failed : %d\n",err);                // Print an error message indicating the failure to update temperature data
    }
	  // status is 0 when button is pressed, and greater than 0 when button is not pressed
	test_polling_mode(vcnl); //entering the polling mode
        
	k_sleep(K_MSEC(500));// delay for 5 secs
	}

	
	return 0;  // Return 0 to indicate successful completion of the function
} 
