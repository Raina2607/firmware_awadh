#include <zephyr/kernel.h>         //header files for the project

#include <zephyr/sys/printk.h>
#include <zephyr/sys_clock.h>
#include <stdio.h>

#include <zephyr/device.h>
#include <zephyr/drivers/sensor.h>
#include <zephyr/drivers/i2c.h>
#include <hal/nrf_gpio.h>

#define I2C_NODE DT_NODELABEL(vcnl4040)   // Define a macro named I2C_NODE

/* Button variables */
static uint32_t time, last_time; // used for detecting long button press
static uint32_t button_counter = 0;  // Declaration and initialization of a static variable `button_counter` of type `uint32_t`
int button_tick = 0;   // Declaration of a non-static variable `button_tick` of type `int`

int sleep_flag = 1;  // Declaration and initialization of a variable `sleep_flag` of type `int`

void enter_sleep(void)  // Function declaration for entering sleep mode
{

	printk("Entering SYSTEM-OFF mode\n");   // Print a message indicating that the system is entering SYSTEM-OFF mode
	NRF_POWER->SYSTEMOFF = 1;  // Set the SYSTEMOFF bit in the NRF_POWER register to 1 to put the system into SYSTEM-OFF mode
}

#if defined(CONFIG_VCNL4040_ENABLE_ALS)  // Check if the macro CONFIG_VCNL4040_ENABLE_ALS is defined
static void print_als_data(const struct device *dev)  // Function declaration for printing ALS (Ambient Light Sensor) data
{
	struct sensor_value val;  // Declaration of a variable named `val` of type `struct sensor_value`

	if (sensor_channel_get(dev, SENSOR_CHAN_LIGHT, &val) < 0) {//fetching sensor lux data and storing in val
		printf("ALS read error.\n");  // Print an error message indicating that there was an ALS (Ambient Light Sensor) read error
		return;  // Exit the function, as there's nothing more to be done after encountering the error
	}

	printf("Light (lux): %d\n", (uint16_t) val.val1); //val1 stores the integer part of the val
}
#endif          // End of a conditional compilation block started with #if directive
static void test_polling_mode(const struct device *dev)   // Function definition for test_polling_mode, which likely tests polling mode of a device
{
		if (sensor_sample_fetch(dev) < 0) {
			// printf("sample update error.\n");//if the sensor data isn't fetched it prints this statement
		} else {
			// print_proxy_data(dev);//goes into the function to print proxy data
#if defined(CONFIG_VCNL4040_ENABLE_ALS) //if the config is enabled, enters the function print_als_data, prints lux data
			print_als_data(dev);  
#endif   // End of a conditional compilation block started with #if directive
		}

}

int main(void)                 //main function
{ 
	int ret;       // Variable to hold return values from functions
	int j = 0;     // Variable used as a loop counter
	const struct device *const vcnl = DEVICE_DT_GET_ANY(vishay_vcnl4040);     // Declaration and initialization of a constant pointer to a constant device structure  & // The device is retrieved using DEVICE_DT_GET_ANY() macro with the compatible string "vishay_vcnl4040"

	if (!device_is_ready(vcnl)) {   // Check if the device pointed to by 'vcnl' is not ready
		printk("sensor: device not ready.\n"); //if the i2c address doesn't match or wrong assignments of pins, this is printed
		return 0;   // Return 0 to indicate successful completion of the function
	}
	nrf_gpio_cfg_output(DT_GPIO_PIN(DT_NODELABEL(led3), gpios));
	nrf_gpio_pin_set(DT_GPIO_PIN(DT_NODELABEL(led3), gpios)); // make pin28 high

	nrf_gpio_cfg_input(DT_GPIO_PIN(DT_NODELABEL(button0), gpios), // enable button0 as input pin
					   NRF_GPIO_PIN_PULLUP);
	nrf_gpio_cfg_sense_set(DT_GPIO_PIN(DT_NODELABEL(button0), gpios),
						   NRF_GPIO_PIN_SENSE_LOW); // Button is 0 when it is pressed.

	int status = nrf_gpio_pin_read(DT_GPIO_PIN(DT_NODELABEL(button0), gpios)); // status variable carries current status of the pin.

	printk("button status=%d\n", status); // status is 0 when button is pressed, and greater than 0 when button is not pressed

	while (nrf_gpio_pin_read(DT_GPIO_PIN(DT_NODELABEL(button0), gpios)) == 0) // return value zero indicates that the button is pressed
	{

		time = k_uptime_get(); // get the time elapsed since the device booted up (in milliseconds)

		if (button_counter == 0)
		{
			last_time = time; // will be executed only once.
		}

		if (last_time + 3000 == time) // counts 5 seconds since the start of the button press. Change the value to 2000 for 2 seconds long press
		{

			button_counter = 0;
			sleep_flag = 0; // the flag takes the value zero only when the button is pressed continuously for 5 seconds
			printk("Button was pressed continuously for 5 seconds..\n");  // Print a message indicating that the button was pressed continuously for 5 seconds
			printk("last time=%d\n", last_time);  // Print the value of 'last_time', which likely represents the time of the last button press
			printk("time=%d\n", time);  // Print the current time, likely representing the duration for which the button has been pressed

			while (j <= 5) // toggling of led0 is used as an idication that 5 seconds have elapsed since we press the button
			{
				nrf_gpio_cfg_output(DT_GPIO_PIN(DT_NODELABEL(led0), gpios)); // configure led0 as the output pin
				nrf_gpio_pin_toggle(DT_GPIO_PIN(DT_NODELABEL(led0), gpios)); // toggle the LED
				k_sleep(K_MSEC(50));   // delay
				j++;  // Increment the value of 'j' by 1
			}
			break; // when button is pressed continuously for 5 seconds, blink led0. Then come out of the loop, set parameters and start advertising
		}

		button_counter = button_counter + 1;  // Increment the value of 'button_counter' by 1
	} 

	while (sleep_flag)               // Start of a while loop that continues iterating as long as the condition sleep_flag is true (non-zero)
	{
		enter_sleep(); // as long as the sleep flag is 1, stay in deep sleep mode.
	}

	while(1){//initialise loop to continuosly fetch data

	printk("Starting vcnl4040 for Lux \n");
	test_polling_mode(vcnl); //entering the polling mode

	k_sleep(K_MSEC(2000));// delay for 5 secs
	}

	
	return 0;   // Return 0 to indicate successful completion of the function
}
