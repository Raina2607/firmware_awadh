#include <zephyr/zephyr.h>                         // header files for the project       
#include <zephyr/device.h>  
#include <zephyr/drivers/i2c.h>
#include <zephyr/drivers/sensor.h>
#include <stdio.h>
#include <zephyr/drivers/sensor/sht4x.h>


#define SLEEP_TIME_MS   1000;           // Define sleep time of 1 SEC

void main(void)
{
  
  const struct device *sht = DEVICE_DT_GET_ANY(sensirion_sht4x);   //define sensirion sht4x inside devicetree

   int err; ///creating variable 
   struct sensor_value temp,hum;     // Declare variables to store sensor values for temperature and humidity


if(!device_is_ready(sht))                 // Check if the SHT device is not ready
{
  printf("device %s is not ready\n",sht->name);         // Print an error message indicating that the device is not ready
  return;                                            // Exit the function
}

  while(true)                                      // Enter into an infinite loop for continuous operation
{


  err= sensor_sample_fetch(sht);                    // Fetch sensor samples from the SHT device

  if (err==0)                                          // Check if the sampling operation was successful
{
   sensor_channel_get(sht,SENSOR_CHAN_AMBIENT_TEMP,&temp);   // Declare variables to store temperature and humidity values
   sensor_channel_get(sht,SENSOR_CHAN_HUMIDITY,&hum);         
   
 printf("Temperature= %f C; Humidity= %f %%RH\n", sensor_value_to_double(&temp), sensor_value_to_double(&hum));   // Print temperature and humidity values
}

else{                                                                      // If there was an error fetching sensor samples
  printf("ERROR: Temperature data update failed : %d\n",err);                // Print an error message indicating the failure to update temperature data
}


  
k_sleep(K_MSEC(1000));                                       // Delay execution for 1000 milliseconds
}
}