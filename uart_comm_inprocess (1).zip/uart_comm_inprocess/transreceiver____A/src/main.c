// #include <zephyr/zephyr.h>
// #include <zephyr/device.h>
// #include <zephyr/drivers/uart.h>
// #include <zephyr/sys/printk.h>
// #include <zephyr/logging/log.h>

// LOG_MODULE_REGISTER(main, LOG_LEVEL_DBG);

// #define UART_DEVICE_NODE DT_CHOSEN(zephyr_console)
// #define UART_BUF_SIZE 64

// static const struct device *uart_dev = DEVICE_DT_GET(UART_DEVICE_NODE);
// static char tx_buf[] = "Hi\n";
// static char rx_buf[UART_BUF_SIZE];
// static int rx_buf_pos = 0;

// static char* custom_strdup(const char* str)
// {
//     size_t len = strlen(str) + 1;
//     char* copy = k_malloc(len);
//     if (copy) {
//         memcpy(copy, str, len);
//     }
//     return copy;
// }

// static void uart_cb(const struct device *dev, struct uart_event *evt, void *user_data)
// {
//     if (evt->type == UART_RX_RDY) {
//         for (int i = 0; i < evt->data.rx.len; i++) {
//             rx_buf[rx_buf_pos++] = evt->data.rx.buf[i];
//             if (rx_buf[rx_buf_pos - 1] == '\n' || rx_buf_pos >= UART_BUF_SIZE - 1) {
//                 rx_buf[rx_buf_pos] = '\0';
//                 LOG_INF("Received: %s", custom_strdup(rx_buf));
//                 if (strncmp(rx_buf, "Hi", 2) == 0) {
//                     k_sleep(K_SECONDS(10));
//                     const char *response = "Hello\n";
//                     uart_tx(uart_dev, response, strlen(response), SYS_FOREVER_MS);
//                 }
//                 rx_buf_pos = 0;
//             }
//         }
//     } else if (evt->type == UART_TX_DONE) {
//         // Transmission complete
//     } else if (evt->type == UART_RX_DISABLED || evt->type == UART_RX_STOPPED) {
//         uart_rx_enable(dev, rx_buf, sizeof(rx_buf), 100);
//     }
// }

// void main(void)
// {
//     if (!device_is_ready(uart_dev)) {
//         LOG_ERR("UART device not ready");
//         return;
//     }

//     uart_callback_set(uart_dev, uart_cb, NULL);
//     uart_rx_enable(uart_dev, rx_buf, sizeof(rx_buf), 100);

//     while (true) {
//         uart_tx(uart_dev, tx_buf, strlen(tx_buf), SYS_FOREVER_MS);
//         k_sleep(K_MSEC(10000));
//     }
// }


// #define UART_DEV_NAME  DT_LABEL(DT_ALIAS(uart0))  // Get UART device label from device tree alias
// #define MAX_DATA_LEN   50   // Maximum length of data to send/receive

// void main(void)
// {
//     const struct device *uart_dev;

//     uart_dev = device_get_binding(UART_DEV_NAME);
//     if (!uart_dev) {
//         printf("UART device not found\n");
//         return;
//     }

//     // Main loop to send data over UART
//     while (1) {
//         const uint8_t data[] = "Hello, UART!";
//         uart_tx(uart_dev, data, sizeof(data), K_FOREVER);  // Ensure timeout is of type int32_t
//         k_sleep(K_MSEC(1000));  // Delay for demonstration
//     }
// }





















// #define UART_DEVICE_NODE DT_CHOSEN(zephyr_console)

// static const struct device *uart_dev = DEVICE_DT_GET(UART_DEVICE_NODE);

// void main(void) {
//     if (!device_is_ready(uart_dev)) {
//         printk("UART device not found\n");
//         return;
//     }

//     const char *message = "hi\n";
//     while (1) {
//         uart_poll_out(uart_dev, *message++);
//         if (*message == '\0') {
//             message -= 3; // Reset pointer to the start of the message
//             k_sleep(K_SECONDS(10));
//         }
//     }
// }







//final code
// #include <string.h>

// #define UART_DEVICE_LABEL "UART_0"  // Change if necessary

// #define MSG "Hello from NRF52832\n"

// void uart_transmit(const struct device *dev, const char *msg) {
//     for (size_t i = 0; i < strlen(msg); i++) {
//         uart_poll_out(dev, msg[i]);
//     }
// }

// void main(void) {
//     const struct device *uart_dev;
//     struct uart_config uart_cfg = {
//         .baudrate = 115200,
//         .parity = UART_CFG_PARITY_NONE,
//         .stop_bits = UART_CFG_STOP_BITS_1,
//         .data_bits = UART_CFG_DATA_BITS_8,
//         .flow_ctrl = UART_CFG_FLOW_CTRL_NONE
//     };

//     uart_dev = device_get_binding(UART_DEVICE_LABEL);
//     if (!uart_dev) {
//         printk("Cannot find UART device\n");
//         return;
//     }

//     if (uart_configure(uart_dev, &uart_cfg) != 0) {
//         printk("Failed to configure UART\n");
//         return;
//     }

//     while (1) {
//         printk("Transmitting: %s", MSG);
//         uart_transmit(uart_dev, MSG);
//         k_sleep(K_SECONDS(10)); // Transmit every 1 second
//     }
// }

#include <zephyr/zephyr.h>
#include <zephyr/device.h>
#include <zephyr/drivers/uart.h>
#include <zephyr/sys/printk.h>
#include <zephyr/logging/log.h>
#include <string.h>

#define UART_DEVICE_LABEL "UART_0"  // Change if necessary
#define BUFFER_SIZE 64

#define MSG "Hello from NRF52832\n"

void uart_transmit(const struct device *dev, const char *msg) {
    for (size_t i = 0; i < strlen(msg); i++) {
        uart_poll_out(dev, msg[i]);
    }
}

void uart_receive(const struct device *dev, uint8_t *buf, size_t buf_size) {
    size_t i = 0;
    int rx_data;

    while (i < buf_size - 1) {
        rx_data = uart_poll_in(dev, &buf[i]);
        if (rx_data >= 0) {
            if (buf[i] == '\n') {
                break;
            }
            i++;
        } else {
            k_sleep(K_MSEC(10)); // Sleep to avoid busy waiting
        }
    }
    buf[i] = '\0'; // Null-terminate the string
}

void main(void) {
    const struct device *uart_dev;
    struct uart_config uart_cfg = {
        .baudrate = 115200,
        .parity = UART_CFG_PARITY_NONE,
        .stop_bits = UART_CFG_STOP_BITS_1,
        .data_bits = UART_CFG_DATA_BITS_8,
        .flow_ctrl = UART_CFG_FLOW_CTRL_NONE
    };
    uint8_t rx_buffer[BUFFER_SIZE];

    uart_dev = device_get_binding(UART_DEVICE_LABEL);
    if (!uart_dev) {
        printk("Cannot find UART device\n");
        return;
    }

    if (uart_configure(uart_dev, &uart_cfg) != 0) {
        printk("Failed to configure UART\n");
        return;
    }

    while (1) {
        printk("Transmitting: %s", MSG);
        uart_transmit(uart_dev, MSG);
        k_sleep(K_SECONDS(10)); // Transmit every 1 second

        // Receive message from the receiver
        uart_receive(uart_dev, rx_buffer, BUFFER_SIZE);
        printk("Received: %s", rx_buffer);
    }
}