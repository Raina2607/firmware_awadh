// #include <zephyr/zephyr.h>
// #include <zephyr/device.h>
// #include <zephyr/drivers/uart.h>
// #include <zephyr/sys/printk.h>
// #include <zephyr/logging/log.h>

// LOG_MODULE_REGISTER(main, LOG_LEVEL_DBG);

// extern void observer_main(void);

// void main(void)
// {
//     LOG_INF("Initializing receiver...");
//     observer_main();  // Jump to observer_main function in observer.c
// }



// #define UART_DEV_NAME  DT_LABEL(DT_ALIAS(uart0))  // Get UART device label from device tree alias
// #define MAX_DATA_LEN   50   // Maximum length of data to send/receive

// // Prototype for function in observer.c
// void observer_process_uart_data(const uint8_t *data, size_t len);

// void uart_rx_handler(const struct device *dev, struct uart_event *evt, void *user_data)
// {
//     static uint8_t rx_buffer[MAX_DATA_LEN];
//     static int rx_index = 0;

//     switch (evt->type) {
//         case UART_RX_BUF_REQUEST:
//             uart_rx_enable(dev, rx_buffer, sizeof(rx_buffer), K_NO_WAIT);
//             break;

//         case UART_RX_DONE:
//             for (int i = 0; i < evt->data.rx.len; i++) {
//                 rx_buffer[rx_index++] = evt->data.rx.buf[i];
//                 if (rx_index >= MAX_DATA_LEN) {
//                     rx_index = 0;
//                     // Pass received UART data to observer function
//                     observer_process_uart_data(rx_buffer, MAX_DATA_LEN);
//                 }
//             }
//             break;

//         case UART_RX_DISABLED:
//             rx_index = 0;
//             break;

//         default:
//             break;
//     }
// }

// void main(void)
// {
//     const struct device *uart_dev;

//     uart_dev = device_get_binding(UART_DEV_NAME);
//     if (!uart_dev) {
//         printf("UART device not found\n");
//         return;
//     }

//     uart_callback_set(uart_dev, uart_rx_handler, NULL);
//     uart_rx_enable(uart_dev, NULL, 0, K_FOREVER);

//     printf("UART receiver initialized\n");

//     while (1) {
//         k_sleep(K_MSEC(1000));  // Sleep to allow UART reception
//     }
// }

// #include <string.h>

// #define UART_DEVICE_NODE DT_CHOSEN(zephyr_console)

// extern void observer(void);

// void main(void)
// {
//     observer();
// }






// #include <string.h>

// #define UART_DEVICE_NODE DT_CHOSEN(zephyr_console)

// static const struct device *uart_dev = DEVICE_DT_GET(UART_DEVICE_NODE);
// static char rx_buf[3];
// static int rx_pos = 0;

// void uart_cb(const struct device *dev, void *user_data) {
//     if (!uart_irq_update(dev)) {
//         return;
//     }

//     // Check if UART RX is ready
//     if (uart_irq_rx_ready(dev)) {
//         uint8_t c;
//         while (uart_fifo_read(dev, &c, 1)) {
//             rx_buf[rx_pos++] = c;

//             // Check if we have received the full message "hi\n"
//             if (c == '\n' || rx_pos >= sizeof(rx_buf) - 1) {
//                 rx_buf[rx_pos] = '\0';  // Null-terminate the string
//                 printk("Received: %s", rx_buf);

//                 // Check if received message is "hi\n"
//                 if (strcmp(rx_buf, "hi\n") == 0) {
//                     k_sleep(K_SECONDS(10));  // Wait for 10 seconds

//                     const char *reply = "hello\n";
//                     for (const char *p = reply; *p; p++) {
//                         uart_poll_out(dev, *p);
//                     }
//                 }

//                 rx_pos = 0;  // Reset buffer position for next message
//             }
//         }
//     }
// }

// void main(void) {
//     if (!device_is_ready(uart_dev)) {
//         printk("UART device not found\n");
//         return;
//     }

//     // Set UART callback function
//     uart_irq_callback_user_data_set(uart_dev, uart_cb, NULL);
//     // Enable UART RX interrupt
//     uart_irq_rx_enable(uart_dev);

//     printk("UART receiver ready\n");

//     // Main loop does nothing, waiting for UART interrupts
//     while (1) {
//         k_sleep(K_FOREVER);
//     }
// }


//final code till now


// #define UART_DEVICE_LABEL "UART_0"  // Change if necessary
// #define BUFFER_SIZE 64

// void uart_receive(const struct device *dev, uint8_t *buf, size_t buf_size) {
//     size_t i = 0;
//     int rx_data;

//     while (i < buf_size - 1) {
//         rx_data = uart_poll_in(dev, &buf[i]);
//         if (rx_data >= 0) {
//             if (buf[i] == '\n') {
//                 break;
//             }
//             i++;
//         } else {
//             k_sleep(K_MSEC(10)); // Sleep to avoid busy waiting
//         }
//     }
//     buf[i] = '\0'; // Null-terminate the string
// }

// void main(void) {
//     const struct device *uart_dev;
//     struct uart_config uart_cfg = {
//         .baudrate = 115200,
//         .parity = UART_CFG_PARITY_NONE,
//         .stop_bits = UART_CFG_STOP_BITS_1,
//         .data_bits = UART_CFG_DATA_BITS_8,
//         .flow_ctrl = UART_CFG_FLOW_CTRL_NONE
//     };
//     uint8_t rx_buffer[BUFFER_SIZE];

//     uart_dev = device_get_binding(UART_DEVICE_LABEL);
//     if (!uart_dev) {
//         printk("Cannot find UART device\n");
//         return;
//     }

//     if (uart_configure(uart_dev, &uart_cfg) != 0) {
//         printk("Failed to configure UART\n");
//         return;
//     }

//     while (1) {
//         uart_receive(uart_dev, rx_buffer, BUFFER_SIZE);
//         printk("Received: %s", rx_buffer);
//     }
// }

#include <zephyr/zephyr.h>
#include <zephyr/device.h>
#include <zephyr/drivers/uart.h>
#include <zephyr/sys/printk.h>
#include <zephyr/logging/log.h>
#include <string.h>

#define UART_DEVICE_LABEL "UART_0"  // Change if necessary
#define BUFFER_SIZE 64

#define HI_MSG "hi\n"

void uart_receive(const struct device *dev, uint8_t *buf, size_t buf_size) {
    size_t i = 0;
    int rx_data;

    while (i < buf_size - 1) {
        rx_data = uart_poll_in(dev, &buf[i]);
        if (rx_data >= 0) {
            if (buf[i] == '\n') {
                break;
            }
            i++;
        } else {
            k_sleep(K_MSEC(10)); // Sleep to avoid busy waiting
        }
    }
    buf[i] = '\0'; // Null-terminate the string
}

void uart_transmit(const struct device *dev, const char *msg) {
    for (size_t i = 0; i < strlen(msg); i++) {
        uart_poll_out(dev, msg[i]);
    }
}

void main(void) {
    const struct device *uart_dev;
    struct uart_config uart_cfg = {
        .baudrate = 115200,
        .parity = UART_CFG_PARITY_NONE,
        .stop_bits = UART_CFG_STOP_BITS_1,
        .data_bits = UART_CFG_DATA_BITS_8,
        .flow_ctrl = UART_CFG_FLOW_CTRL_NONE
    };
    uint8_t rx_buffer[BUFFER_SIZE];

    uart_dev = device_get_binding(UART_DEVICE_LABEL);
    if (!uart_dev) {
        printk("Cannot find UART device\n");
        return;
    }

    if (uart_configure(uart_dev, &uart_cfg) != 0) {
        printk("Failed to configure UART\n");
        return;
    }

    while (1) {
        uart_receive(uart_dev, rx_buffer, BUFFER_SIZE);
        printk("Received: %s", rx_buffer);

        // Wait for 10 seconds before sending a message back
        k_sleep(K_SECONDS(10));

        printk("Transmitting back: %s", HI_MSG);
        uart_transmit(uart_dev, HI_MSG);
    }
}

