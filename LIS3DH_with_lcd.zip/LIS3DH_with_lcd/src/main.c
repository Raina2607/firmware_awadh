#include <stdio.h> 
#include <lvgl.h>
#include <string.h> 
#include <hal/nrf_gpio.h>                                                  // headers for the project 
#include <zephyr/zephyr.h>
#include <zephyr/kernel.h>
#include <zephyr/device.h>
#include <zephyr/sys/printk.h>
#include <zephyr/drivers/i2c.h>
#include <zephyr/logging/log.h>
#include <zephyr/drivers/gpio.h>
#include <zephyr/drivers/sensor.h>
#include <zephyr/drivers/display.h>

void main(void)                                                        // main function
{
	 const struct device *display_dev;
    lv_obj_t *hello_world_label;
	display_dev = DEVICE_DT_GET(DT_CHOSEN(zephyr_display));
	if (IS_ENABLED(CONFIG_LV_Z_POINTER_KSCAN)) {  //Checks if the Zephyr pointer KSCAN feature is enabled. If not, creates a label object on the active LittlevGL screen.  
    } 
	else {
        hello_world_label = lv_label_create(lv_scr_act());
    }
	char* msg = "Hello AWaDH\n"; //Declares a character array msg with a greeting message and placeholder for temperature. 
    char result[100];
    lv_task_handler();  //Calls the LittlevGL task handler, turns off display blanking, and prints a message indicating the display has been updated.
    display_blanking_off(display_dev);
    printk("Updated display\n");

while(1)                                                               // infinite loop
{	
	static unsigned int count;                                    // Declare an unsigned integer variable named 'count'
	struct sensor_value accel[3];                                 // Declare an array of structures of type 'sensor_value' named 'accel' with size 3
	const char *overrun = "";      
	const struct device *const sensor = DEVICE_DT_GET_ANY(st_lis2dh);                               // Declare a pointer to a constant character array named 'overrun' and initialize it with an empty string
	int rc = sensor_sample_fetch(sensor);
	++count;                                                      // Increment the value of the 'count' variable by 1
	if(rc == -EBADMSG) {                                         // Check if the return code indicates a bad message error
	if (IS_ENABLED(CONFIG_LIS2DH_TRIGGER)) {                  // Check if the LIS2DH trigger configuration is enabled
		overrun = "[OVERRUN] ";                                   // Update the 'overrun' pointer to indicate overrun if trigger configuration is enabled
	}
		rc = 0;                                                    // Reset the return code to 0
	}
	if (rc == 0) {                                                    // Check if the return code is 0
		rc = sensor_channel_get(sensor,SENSOR_CHAN_ACCEL_XYZ,accel);  // Retrieve the accelerometer data for all three axes
	}
	if (rc < 0) {                                                     // Check if the return code is less than 0
		printf("ERROR: Update failed: %d\n", rc);                     // Print an error message indicating the update failure
	} else {
		printf("#%u @ %u ms: %sx %f , y %f , z %f",                   // Print the accelerometer data along with count and timestamp
		       count, k_uptime_get_32(), overrun,                     
		       sensor_value_to_double(&accel[0]),                     // Convert the sensor value of the first axis to a double and print it
		       sensor_value_to_double(&accel[1]),                    // Convert the sensor value of the second axis to a double and print it
		       sensor_value_to_double(&accel[2]));                   // Convert the sensor value of the third axis to a double and print it
	}	
	printf("\n"); 
	// Correctly format the sensor values by converting them to double first
	// Workaround for displaying floating-point numbers without %f support
	int x_int = (int)(sensor_value_to_double(&accel[0]) * 1000);
	int y_int = (int)(sensor_value_to_double(&accel[1]) * 1000);
	int z_int = (int)(sensor_value_to_double(&accel[2]) * 1000);

	sprintf(result, "%s       x %d.%03d\n       y %d.%03d\n       z %d.%03d\n", msg,
		x_int / 1000, abs(x_int % 1000),  // Convert x to integer and format
		y_int / 1000, abs(y_int % 1000),  // Convert y to integer and format
		z_int / 1000, abs(z_int % 1000)); // Convert z to integer and format//This function formats a string using the msg (a greeting message) and the temperature obtained from the sensor, storing it in the result variable.
    lv_label_set_text(hello_world_label, result); //This function updates the text of the label (hello_world_label) with the newly formatted string stored in result.
    lv_obj_align(hello_world_label, LV_ALIGN_CENTER, 0, 0);
	lv_task_handler();
	k_sleep(K_MSEC(100));
}
}