#include <stddef.h>   // header files for the project
#include "headers/main_observer.h"
#include <zephyr/bluetooth/bluetooth.h>
#include <zephyr/bluetooth/hci.h>
#include <zephyr/logging/log.h>
#include <zephyr/kernel.h>
#include <zephyr/sys/printk.h>
#include <zephyr/drivers/gpio.h>
#include <zephyr/pm/pm.h>
#include <zephyr/device.h>
#include <hal/nrf_gpio.h>
#include <zephyr/devicetree.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <errno.h>
#define LOG_LEVEL 4
#include <zephyr/zephyr.h>
#include <zephyr/drivers/led_strip.h>
#include <zephyr/dt-bindings/led/led.h>
#include <zephyr/drivers/i2s.h>
#include <zephyr/sys/util.h>

int rc;   // Declare an integer variable 'rc'

uint8_t remote1 = 1;  // Initialize variable 'remote1' with value 1
uint8_t remote2 = 2;  // Initialize variable 'remote1' with value 2

#define LED1_NODE DT_ALIAS(led1)  // Define a macro 'LED1_NODE' to represent the device tree alias 'led1'
static const struct gpio_dt_spec led1 = GPIO_DT_SPEC_GET(LED1_NODE, gpios);  // Define a constant structure 'led1' using GPIO_DT_SPEC_GET with the 'LED1_NODE' alias

#define LED0_NODE DT_ALIAS(led0)  // Define a macro 'LED0_NODE' to represent the device tree alias 'led0'
static const struct gpio_dt_spec led0 = GPIO_DT_SPEC_GET(LED0_NODE, gpios);  // Define a constant structure 'led' using GPIO_DT_SPEC_GET with the 'LED0_NODE' alias

#define STACKSIZE	 2048  // Define the stack size for threads as 2048 bytes
#define THREAD0_PRIORITY 7  // Define the priority level for Thread 0 as 7
static int counter_remote1 = 0;  // Initialize counters for remote devices
static int counter_remote2 = 1;  
LOG_MODULE_DECLARE(gateway, LOG_LEVEL_DBG);  // Declare a logging module named 'gateway' with debug logging level
 
/* Index write_index to write data in flash */
// extern int write_index = 0;
#define n  3  // Define a macro 'n' with the value 3
#define n1 3  // Define another macro 'n1' with the value 3

/* It is data callback function. It is executed whenever the system recieves an advertising packet.
 */
#if defined(CONFIG_BT_EXT_ADV)
static bool data_cb(struct bt_data *data, void *user_data)
{
	int chunk_size = pow(2, n1); // total number of bytes to be written in one write operation [max.= 128]
	uint8_t write_array[chunk_size];
	write_array[0] = 0;
	/* data_cb is executed whenever some advertising packet comes. */
	LOG_INF("IN DATA CB");
	// len is the length of the advertising packet.
	// uint8_t len;
	switch (data->type) {
	case BT_DATA_NAME_SHORTENED:  // Handle Bluetooth data of type BT_DATA_NAME_SHORTENED
	case BT_DATA_NAME_COMPLETE:   // Handle Bluetooth data of type BT_DATA_NAME_COMPLETE
	case BT_DATA_MANUFACTURER_DATA:  // Handle Bluetooth data of type BT_DATA_MANUFACTURER_DATA

		int index = 0;   // Initialize an integer variable 'index' with the value 0

		/* It is just a variable that runs from 0 to 128. */
		int j = 0;

		// Storing chunk_size BYTES OF DATA AT ONCE //
		for (j = 0; j < chunk_size; j++) {
			/* Using char (char = 1 byte uint8_t type). */
			char number = data->data[j + index];
			/* Appending them in write array. */
			write_array[j] = number;
			printk("%d ", write_array[j]);
		}
	}

	if (write_array[0] == remote1) {  // Check if the first byte of the received data matches the value of remote1
		// Increment the counter for remote1
		if (counter_remote1 == 0) {  // Check if the counter for remote1 is equal to 0
			counter_remote1++;
			gpio_pin_set_dt(&led0, 1);
			gpio_pin_set_dt(&led1, 0);
			printf("%d\n", counter_remote1);
		} else if (counter_remote1 == 1) {  // Check if the counter for remote1 is equal to 1
			gpio_pin_set_dt(&led1, 1);
			gpio_pin_set_dt(&led0, 0);
			counter_remote1=0;
		}
	} 
	
	if (write_array[0] == remote2) {  // Check if the first byte of the received data matches the value of remote2
  // Increment the counter for remote2
		if (counter_remote2 == 1) {  // Check if the counter for remote2 is equal to 1
			counter_remote2++;
			gpio_pin_set_dt(&led0, 1);
			gpio_pin_set_dt(&led1, 0);
			printf("%d\n", counter_remote2);
		} else if (counter_remote2 == 2) {  // Check if the counter for remote2 is equal to 2
			gpio_pin_set_dt(&led1, 1);
			gpio_pin_set_dt(&led0, 0);
			counter_remote2=1;
		}
	}
	return true;
}

static void scan_recv(const struct bt_le_scan_recv_info *info, struct net_buf_simple *buf)
{
	/* Executed when we recieve the packet from advertising node. */
	char le_addr[BT_ADDR_LE_STR_LEN];
	uint8_t data_status;
	uint16_t data_len;
	char name[30];
	data_len = buf->len;  // Get the length of the data received in the network buffer 'buf'

	bt_data_parse(buf, data_cb, name);  // Parse the Bluetooth data in the network buffer using the bt_data_parse function

	data_status = BT_HCI_LE_ADV_EVT_TYPE_DATA_STATUS(info->adv_props);  // Extract the data status from the received scan information

	bt_addr_le_to_str(info->addr, le_addr, sizeof(le_addr));  // Convert the Bluetooth device address in 'info->addr' to a string format and store it in 'le_addr'
}

static struct bt_le_scan_cb scan_callbacks = {  // Define a structure named 'scan_callbacks' of type 'struct bt_le_scan_cb'
	.recv = scan_recv,  // Assign the 'scan_recv' function as the callback for received scan data
};
#endif /* CONFIG_BT_EXT_ADV */

int observer_start(void)
{

	bt_addr_le_t addr1;  // Declare a Bluetooth LE address structure
	gpio_pin_configure_dt(&led0, GPIO_OUTPUT_ACTIVE);
	gpio_pin_configure_dt(&led1, GPIO_OUTPUT_ACTIVE);

	bt_addr_le_from_str("DE:AD:BE:AF:BA:12", "random", &addr1);  // Convert a string representation of a Bluetooth device address to a Bluetooth LE address structure

	int err = bt_le_filter_accept_list_add(&addr1);   // Add the address 'addr1' to the Filter Accept List for Bluetooth LE scanning
	if (err == 0) {   // Check if the operation to add the address to the Filter Accept List was successful
		printk("Successfully added the address to Filter Accept List..\n");   // Print success message
	} else {
		printk("Failed to update Filter Accept List..\n"); // Print failure message
	}  

	struct bt_le_scan_param scan_param = {  // Define a structure 'scan_param' of type 'struct bt_le_scan_param' to configure LE scan parameters
		.type = BT_LE_SCAN_TYPE_PASSIVE,    // Set scan type to passive (does not send scan requests)
		.options = BT_LE_SCAN_OPT_FILTER_DUPLICATE | BT_LE_SCAN_OPT_FILTER_ACCEPT_LIST,   // Enable filter for duplicate advertisements and filter using the accept list
		.interval = 0x0030,  // Set scan interval to 30 units (typically in 0.625 ms units)
		.window = 0x0030,    // Set scan window to 30 units (typically in 0.625 ms units)
	};

	bt_le_scan_cb_register(&scan_callbacks);  // Register the scan callback functions defined in 'scan_callbacks' with the Bluetooth LE scanning module
	err = bt_le_scan_start(&scan_param, NULL);  // Start Bluetooth LE scanning with the configured scan parameters in 'scan_param'

	if (err) {   // check if the error
		LOG_INF("Start scanning failed (err %d)\n", err);  // Log an informational message indicating that scanning failed, along with the error code
		return err;  // Return the error code to the caller of the function
	}
	LOG_INF("Started scanning...\n");  // Log an informational message indicating that scanning has started
	return 0; // Return 0 to indicate successful start of scanning
}

int init_observer(void)  
{
	/* Observer Initialization. */
	LOG_ERR("observer init.....");

	/* Enabling Bluetooth. */
	int err = bt_enable(NULL);  // Enable Bluetooth functionality with default settings
	if (err) {  // Check if enabling Bluetooth was successful
		LOG_ERR("Bluetooth init failed (err %d)\n", err);    // Log an error message indicating Bluetooth initialization failure, along with the error code
		return err;   // Return the error code to the caller of the function
	}

	return 0;  // Return 0 to indicate successful Bluetooth initialization
}

