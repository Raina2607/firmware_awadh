#include <zephyr/zephyr.h>      // header files for the project
#include <zephyr/device.h>
#include <zephyr/devicetree.h>
#include <zephyr/drivers/i2c.h>
#include <zephyr/sys/printk.h>
#include <stdio.h>
#include <zephyr/zephyr.h>
#include <zephyr/drivers/gpio.h>
#include <zephyr/device.h>
#include <zephyr/pm/pm.h>
#include <hal/nrf_gpio.h>
#include <zephyr/drivers/sensor.h>

#define SLEEP_TIME_MS 1000                // Define the sleep time in milliseconds

#define STTS751_TEMP_HIGH_REG 0x00       // Define the register address for temperature high threshold in STTS751
#define STTS751_TEMP_LOW_REG 0x02       // Define the register address for temperature low threshold in STTS751
#define STTS751_CONFIG_REG 0x03         // Define the register address for configuration register in STTS751

/* Button variables */
static uint32_t time, last_time;         //used for detecting long button press
static uint32_t button_counter=0;        // Declare and initialize a static variable to store button counter value
int button_tick = 0;                     // Declare and initialize an integer variable to represent button tick

int sleep_flag=1;                        // Declare and initialize an integer variable to represent the sleep flag

#define I2C_NODE DT_NODELABEL(mysensor)  // Define the I2C node label for the sensor "mysensor"

void enter_sleep(void)                  // Function to enter sleep mode
{

  printk("Entering SYSTEM-OFF mode\n");  // Print a message indicating the entry into SYSTEM-OFF mode  
  NRF_POWER->SYSTEMOFF = 1;              // Set the SYSTEMOFF bit in the NRF_POWER register to initiate system-off mode
}

void main(void)                         // main function
{

	int ret;                           // Declare an integer variable to store the return value
	int j=0;                           // Declare an integer variable to store the return value

	static const struct i2c_dt_spec dev_i2c = I2C_DT_SPEC_GET(I2C_NODE);   // Define a static constant structure to hold the I2C device specification retrieved from the device tree node labeled "mysensor"
	if (!device_is_ready(dev_i2c.bus))                                  // Check if the I2C bus associated with the device is not ready
	{     
		printk("I2C bus %s is not ready!\n\r", dev_i2c.bus->name);     // Print an error message indicating that the I2C bus is not ready
		return;                                                        // Exit the function as the I2C bus is not ready for communication
	}

	uint8_t buffer[2] = {STTS751_CONFIG_REG, 0x8C};                   // Define a buffer containing the configuration register address and data
	ret = i2c_write_dt(&dev_i2c, buffer, sizeof(buffer));             // Write data to the I2C device using the device-specific I2C specification and store the return value
	if (ret != 0)                                                     // Check if the return value from the I2C write operation is not zero, indicating a failure
	{
		printk("Failed to write to I2C device address %x at Reg. %x \n", dev_i2c.addr, buffer[0]);   // Print an error message indicating the failure to write to the I2C device at the specified register address
		return;                                                         // Exit the function as the write operation failed
	}
	nrf_gpio_cfg_output(DT_GPIO_PIN(DT_NODELABEL(led3), gpios));       // Configure GPIO pin for output using the pin information obtained from the device tree
	nrf_gpio_pin_set(DT_GPIO_PIN(DT_NODELABEL(led3), gpios)); // make pin28 high

	nrf_gpio_cfg_input(DT_GPIO_PIN(DT_NODELABEL(button0), gpios), // enable button0 as input pin
					   NRF_GPIO_PIN_PULLUP);
	nrf_gpio_cfg_sense_set(DT_GPIO_PIN(DT_NODELABEL(button0), gpios),
						   NRF_GPIO_PIN_SENSE_LOW); // Button is 0 when it is pressed.

	int status = nrf_gpio_pin_read(DT_GPIO_PIN(DT_NODELABEL(button0), gpios)); // status variable carries current status of the pin.

	printk("button status=%d\n", status); // status is 0 when button is pressed, and greater than 0 when button is not pressed
   
	while (nrf_gpio_pin_read(DT_GPIO_PIN(DT_NODELABEL(button0), gpios)) == 0) // return value zero indicates that the button is pressed
	{

		time = k_uptime_get(); // get the time elapsed since the device booted up (in milliseconds)

		if (button_counter == 0)  // Check if the button counter is equal to zero
		{
			last_time = time; // will be executed only once.
		}

		if (last_time + 3000 == time) // counts 5 seconds since the start of the button press. Change the value to 2000 for 2 seconds long press
		{

			button_counter = 0;      // Reset the button counter to zero
			sleep_flag = 0; // the flag takes the value zero only when the button is pressed continuously for 5 seconds
			printk("Button was pressed continuously for 5 seconds..\n");   // Print a message indicating that the button was pressed continuously for 5 seconds
			printk("last time=%d\n", last_time);                           
			printk("time=%d\n", time);                                     // Print the value of the last time and current time variables for debugging or informational purposes

			while (j <= 5) // toggling of led0 is used as an idication that 5 seconds have elapsed since we press the button
			{
				nrf_gpio_cfg_output(DT_GPIO_PIN(DT_NODELABEL(led0), gpios)); // configure led0 as the output pin
				nrf_gpio_pin_toggle(DT_GPIO_PIN(DT_NODELABEL(led0), gpios)); // toggle the LED
				k_sleep(K_MSEC(50));
				j++;
			}
			break; // when button is pressed continuously for 5 seconds, blink led0. Then come out of the loop, set parameters and start advertising
		}

		button_counter = button_counter + 1;        // Increment the button counter by one
	} 

	while (sleep_flag)                   // Continue the loop as long as the sleep flag is true (non-zero)
	{
		enter_sleep(); // as long as the sleep flag is 1, stay in deep sleep mode.
	}

	while (1)        // Infinite loop
	{

		uint8_t temp_reading[2] = {0};          // Define an array to store temperature readings
		uint8_t sensor_regs[2] = {STTS751_TEMP_LOW_REG, STTS751_TEMP_HIGH_REG};  // Define an array containing sensor register addresses for temperature low and high
		ret = i2c_write_read_dt(&dev_i2c, &sensor_regs[0], 1, &temp_reading[0], 1);   // Perform an I2C write-read operation to read temperature data from the sensor
		if (ret != 0)                               // Check if the return value from the I2C operation indicates a failure
		{
			printk("Failed to write/read I2C device address %x at Reg. %x \r\n", dev_i2c.addr, sensor_regs[0]);   // Print an error message indicating the failure to write/read from the I2C device at the specified register address
		}
		ret = i2c_write_read_dt(&dev_i2c, &sensor_regs[1], 1, &temp_reading[1], 1);   // Perform an I2C write-read operation to read temperature data from the sensor
		if (ret != 0)                                     // Check if the return value from the I2C operation indicates a failure
		{
			printk("Failed to write/read I2C device address %x at Reg. %x \r\n", dev_i2c.addr, sensor_regs[1]);   // Print an error message indicating the failure to write/read from the I2C device at the specified register address
		}

		int temp = ((int)temp_reading[1] * 256 + ((int)temp_reading[0] & 0xF0)) / 16;             // Calculate the temperature reading from the raw data obtained from the sensor
		if (temp > 2047)                                                                         // Check if the temperature reading exceeds the range of positive values
		{
			temp -= 4096;                                                                        // Adjust the temperature value for negative temperature readings
		}

		double cTemp = temp * 0.0625;                         // Calculate temperature in Celsius and Fahrenheit                             
		double fTemp = cTemp * 1.8 + 32;

		printk("Temperature in Celsius : %.2f C \n", cTemp);
		printk("Temperature in Fahrenheit : %.2f F \n", fTemp);               // Print temperature in Celsius and Fahrenheit
		k_msleep(SLEEP_TIME_MS);                                              // Delay execution for specified time (in milliseconds)
	}
}