
#include <stdio.h>                     //Library files needed to run the project
#include <lvgl.h>
#include <string.h>
#include <zephyr/device.h>
#include <zephyr/kernel.h>
#include <zephyr/device.h>
#include <zephyr/sys/printk.h>
#include <zephyr/drivers/i2c.h>
#include <zephyr/logging/log.h>
#include <zephyr/drivers/sensor.h>
#include <zephyr/drivers/display.h>
#include <zephyr/drivers/sensor/sht4x.h>

#define LOG_LEVEL CONFIG_LOG_DEFAULT_LEVEL   //This section defines the log level and registers the module for logging with the name "app".
LOG_MODULE_REGISTER(app);

void main(void)                              //The main function, entry point of the program.   
{
    int16_t count = 0U;                       //Variable declarations:
    const struct device *display_dev;
    lv_obj_t *hello_world_label;
    const struct device *sht = DEVICE_DT_GET_ANY(sensirion_sht4x);
    struct sensor_value temp1;
    if (sensor_sample_fetch(sht)) {                 //Checks if sampling from the SHT4X sensor was successful. If not, it prints an error message and exits the program.           
            printf("Failed to fetch sample from SHT4X device\n");
            return;
        }
    sensor_channel_get(sht, SENSOR_CHAN_AMBIENT_TEMP, &temp1);     //Reads the temperature from the SHT4X sensor and prints it out.
    printf("SHT4X: %.2f Temp. [C] ;\n",sensor_value_to_double(&temp1));
    k_sleep(K_MSEC(500));                                                     //Delays the program execution for 500 milliseconds.
    display_dev = DEVICE_DT_GET(DT_CHOSEN(zephyr_display));          //Retrieves the display device from the device tree
    if (!device_is_ready(display_dev)) {                            //Checks if the display device is ready. If not, logs an error and exits the program.  
        LOG_ERR("Device not ready, aborting test");
        printk("Could not get %s device\n", display_dev);
        return;
    }

    if (IS_ENABLED(CONFIG_LV_Z_POINTER_KSCAN)) {  //Checks if the Zephyr pointer KSCAN feature is enabled. If not, creates a label object on the active LittlevGL screen.
        
    } else {
        hello_world_label = lv_label_create(lv_scr_act());
    }

    char* msg = "Hello AWaDH\n Temperature \n"; //Declares a character array msg with a greeting message and placeholder for temperature. 
    char result[100];
    lv_task_handler();  //Calls the LittlevGL task handler, turns off display blanking, and prints a message indicating the display has been updated.
    display_blanking_off(display_dev);
    printk("Updated display\n");
    
    while (1) {     //Enters an infinite loop where it repeatedly fetches the temperature from the sensor, 
                    //formats the message with the temperature, updates the label text, and aligns it to the center of the screen.
        
        lv_task_handler();  //This function call executes tasks related to LittlevGL, such as updating the user interface.
        if (sensor_sample_fetch(sht)) {    //This conditional statement checks if fetching a sample from the SHT4X sensor was successful.
                                           // If not, it prints an error message and exits the program.
        printf("Failed to fetch sample from SHT4X device\n");
        return;
        }
        sensor_channel_get(sht, SENSOR_CHAN_AMBIENT_TEMP, &temp1);  //This function retrieves the ambient temperature from the SHT4X sensor and stores it in the temp1 variable.
        printf("SHT4X: %.2f Temp. [C] ;\n", sensor_value_to_double(&temp1)); //This line prints out the ambient temperature obtained from the sensor with two decimal places.
        k_sleep(K_MSEC(500));  // This function call suspends execution for 500 milliseconds, creating a delay before the next iteration.
        sprintf(result, "%s        %d °C ", msg, temp1);//This function formats a string using the msg (a greeting message) and the temperature obtained from the sensor, storing it in the result variable.
        lv_label_set_text(hello_world_label, result); //This function updates the text of the label (hello_world_label) with the newly formatted string stored in result.
         lv_obj_align(hello_world_label, LV_ALIGN_CENTER, 0, 0); //This function call aligns the label (hello_world_label) to the center of the display.

    }
}
